function Quiz(questions) {
    this.score = 0;
    this.questions = questions;
    this.questionIndex = 0;
}

Quiz.prototype.getQuestionIndex = function() {
    return this.questions[this.questionIndex];
}

Quiz.prototype.guess = function(answer) {
  
    if(this.getQuestionIndex().isCorrectAnswer(answer)) {
        this.score++;
    }

    this.questionIndex++;
}

Quiz.prototype.isEnded = function() {
    return this.questionIndex === this.questions.length;
}


function Question(text, choices, answer, difficulty, category) {
    this.text = text;
    this.choices = choices;
    this.answer = answer;
    this.difficulty=difficulty;
    this.category=category;
}

Question.prototype.isCorrectAnswer = function(choice) {
    return this.answer === choice;
}

function populate() {
    if(quiz.isEnded()) {
        showScores();
    }
    else {
        // show question
        var element = document.getElementById("question");
        element.innerHTML = quiz.getQuestionIndex().text;

        
        // show options
        var choices = quiz.getQuestionIndex().choices;
        for(var i = 0; i < choices.length; i++) {
            var element = document.getElementById("choice" + i);
            element.innerHTML = choices[i];
            guess("btn" + i, choices[i]);

        }


        var diffi = document.getElementById("lvl");
        diffi.innerHTML = "<strong><u>DIFFICULTY &nbsp</u></strong>= " + quiz.getQuestionIndex().difficulty;



        var cat = document.getElementById("ct");
        cat.innerHTML = "<strong><u>CATEGORY &nbsp</u></strong>= "+quiz.getQuestionIndex().category;

        showProgress();
    }
};

function guess(id, guess) {
    var button = document.getElementById(id);
    button.onclick = function() {
        quiz.guess(guess);
        document.getElementById('btn0').setAttribute('style','background-color:#808000');
        document.getElementById('btn1').setAttribute('style','background-color:#808000');
        document.getElementById('btn2').setAttribute('style','background-color:#808000');
        document.getElementById('btn3').setAttribute('style','background-color:#808000');
        button.setAttribute('style',"background-color:red");
        
    }
};

function nyt()
{
    populate();
    document.getElementById('btn0').setAttribute('style','background-color:#808000');
     document.getElementById('btn1').setAttribute('style','background-color:#808000');
      document.getElementById('btn2').setAttribute('style','background-color:#808000');
       document.getElementById('btn3').setAttribute('style','background-color:#808000');
}

function prm()
{
    var conf=confirm("Do you want to retake quiz?");
    if(conf)
    {
        location.replace("index.html");
        
    }
}

function showProgress() {
    var currentQuestionNumber = quiz.questionIndex + 1;
    var element = document.getElementById("progress");
    element.innerHTML = "Question " + currentQuestionNumber + " of " + quiz.questions.length;
    
};

function showScores() {
    var gameOverHTML = "<h1>Result</h1>";
    gameOverHTML += "<h2 id='score'> Your scores: " + quiz.score + "</h2>";
    
    
    var per=(quiz.score/quiz.questions.length)*100;

    if(per>=70)
    {
        gameOverHTML+="<h2 id='score'> Well done! You are Pass.</h2>"
    }
    else
    {
        gameOverHTML+="<h2 id='score'> Sorry! you are fail.</h2>"
    }
    gameOverHTML+="<h2 id='score'> Time Used - &nbsp"+parseInt(timePassed/60)+":"+timePassed%60+"</h2>";

    /*if(timePassed/60 <1)
        gameOverHTML+="<h2 id='score'>0:</h2>";
    else
    {
        var tm=parseInt(timePassed/60);
        gameOverHTML+="<h2 id='score'>"+tm+"</h2>";

    }
*/
    gameOverHTML+="<h2 id='score'>&nbsp &nbsp &nbsp Percentage:"+ per.toFixed(2) +"</h2>";


    var element = document.getElementById("quiz");
   
    element.innerHTML = gameOverHTML;
    setTimeout(prm,1000);

};




// create questions here
var questions = [
    new Question("Q-Hyper Text Markup Language Stand For?", ["JavaScript", "XHTML","CSS", "HTML"], "HTML","Medium","Technical:sql"),
    new Question("Q-Which language is used for styling web pages?", ["HTML", "JQuery", "CSS", "XML"], "CSS","Easy","Technical:webtechnology"),
    new Question("Q-Which is not a JavaScript Framework?", ["Python Script", "JQuery","Django", "NodeJS"], "Django","Easy","Technical:webtechnology"),
    new Question("Q-Which is used for Connect To Database?", ["PHP", "HTML", "JS", "All"], "PHP","Hard","Technical:webtechnology"),
    new Question("Q-Technologies in MAQ", ["Power BI", "C#", "Typescript", "All"], "All","Easy","General"),
    new Question("Q-Technologies in MAQ", ["MAQ", "Maintain a queue", "May always quality", "Don't Know"], "Don't Know","Easy","General"),
   /* new Question("Q-Hyper Text Markup Language Stand For?", ["JavaScript", "XHTML","CSS", "HTML"], "HTML","Easy","Technical:sql"),
    new Question("Q-Which language is used for styling web pages?", ["HTML", "JQuery", "CSS", "XML"], "CSS","Easy","Technical:webtechnology"),
    new Question("Q-Which is not a JavaScript Framework?", ["Python Script", "JQuery","Django", "NodeJS"], "Django","Easy","Technical:webtechnology"),
    new Question("Q-Which is used for Connect To Database?", ["PHP", "HTML", "JS", "All"], "PHP","Easy","Technical:webtechnology"),
    new Question("Q-Technologies in MAQ", ["Power BI", "C#", "Typescript", "All"], "All","Easy","General"),
    new Question("Q-Technologies in MAQ", ["MAQ", "Maintain a queue", "May always quality", "Don't Know"], "Don't Know","Easy","General"),
    new Question("Q-Hyper Text Markup Language Stand For?", ["JavaScript", "XHTML","CSS", "HTML"], "HTML","Easy","Technical:sql"),
    new Question("Q-Which language is used for styling web pages?", ["HTML", "JQuery", "CSS", "XML"], "CSS","Easy","Technical:webtechnology"),
    new Question("Q-Which is not a JavaScript Framework?", ["Python Script", "JQuery","Django", "NodeJS"], "Django","Easy","Technical:webtechnology"),
    new Question("Q-Which is used for Connect To Database?", ["PHP", "HTML", "JS", "All"], "PHP","Easy","Technical:webtechnology"),
    new Question("Q-Technologies in MAQ", ["Power BI", "C#", "Typescript", "All"], "All","Easy","General"),
    new Question("Q-Technologies in MAQ", ["MAQ", "Maintain a queue", "May always quality", "Don't Know"], "Don't Know","Easy","General"),
    new Question("Q-Hyper Text Markup Language Stand For?", ["JavaScript", "XHTML","CSS", "HTML"], "HTML","Easy","Technical:sql"),
    new Question("Q-Which language is used for styling web pages?", ["HTML", "JQuery", "CSS", "XML"], "CSS","Easy","Technical:webtechnology"),
    new Question("Q-Which is not a JavaScript Framework?", ["Python Script", "JQuery","Django", "NodeJS"], "Django","Easy","Technical:webtechnology"),
    new Question("Q-Which is used for Connect To Database?", ["PHP", "HTML", "JS", "All"], "PHP","Easy","Technical:webtechnology"),
    new Question("Q-Technologies in MAQ", ["Power BI", "C#", "Typescript", "All"], "All","Easy","General"),
    new Question("Q-Technologies in MAQ", ["MAQ", "Maintain a queue", "May always quality", "Don't Know"], "Don't Know","Easy","General")
    */
];

// create quiz
var quiz = new Quiz(questions);

// display quiz
populate();





// timer code

const FULL_DASH_ARRAY = 283;
const WARNING_THRESHOLD = 10;
const ALERT_THRESHOLD = 5;

const COLOR_CODES = {
  info: {
    color: "green"
  },
  warning: {
    color: "orange",
    threshold: WARNING_THRESHOLD
  },
  alert: {
    color: "red",
    threshold: ALERT_THRESHOLD
  }
};

const TIME_LIMIT = 1800;
let timePassed = 0;
let timeLeft = TIME_LIMIT;
let timerInterval = null;
let remainingPathColor = COLOR_CODES.info.color;

document.getElementById("app").innerHTML = `
<div class="base-timer">
  <svg class="base-timer__svg" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
    <g class="base-timer__circle">
      <circle class="base-timer__path-elapsed" cx="50" cy="50" r="45"></circle>
      <path
        id="base-timer-path-remaining"
        stroke-dasharray="283"
        class="base-timer__path-remaining ${remainingPathColor}"
        d="
          M 50, 50
          m -45, 0
          a 45,45 0 1,0 90,0
          a 45,45 0 1,0 -90,0
        "
      ></path>
    </g>
  </svg>
  <span id="base-timer-label" class="base-timer__label">${formatTime(
    timeLeft
  )}</span>
</div>
`;

startTimer();

function onTimesUp() {
  clearInterval(timerInterval);
  showScores();
  //prm();
}

function startTimer() {
  timerInterval = setInterval(() => {
    timePassed = timePassed += 1;
    timeLeft = TIME_LIMIT - timePassed;
    document.getElementById("base-timer-label").innerHTML = formatTime(timeLeft);
    setCircleDasharray();
    setRemainingPathColor(timeLeft);

    if (timeLeft === 0) {
      onTimesUp();
    }
  }, 1000);
}

function formatTime(time) {
  const minutes = Math.floor(time / 60);
  let seconds = time % 60;

  if (seconds < 10) {
    seconds = `0${seconds}`;
  }

  return `${minutes}:${seconds}`;
}

function setRemainingPathColor(timeLeft) {
  const { alert, warning, info } = COLOR_CODES;
  if (timeLeft <= alert.threshold) {
    document
      .getElementById("base-timer-path-remaining")
      .classList.remove(warning.color);
    document
      .getElementById("base-timer-path-remaining")
      .classList.add(alert.color);
  } else if (timeLeft <= warning.threshold) {
    document
      .getElementById("base-timer-path-remaining")
      .classList.remove(info.color);
    document
      .getElementById("base-timer-path-remaining")
      .classList.add(warning.color);
  }
}

function calculateTimeFraction() {
  const rawTimeFraction = timeLeft / TIME_LIMIT;
  return rawTimeFraction - (1 / TIME_LIMIT) * (1 - rawTimeFraction);
}

function setCircleDasharray() {
  const circleDasharray = `${(
    calculateTimeFraction() * FULL_DASH_ARRAY
  ).toFixed(0)} 283`;
  document
    .getElementById("base-timer-path-remaining")
    .setAttribute("stroke-dasharray", circleDasharray);
}



